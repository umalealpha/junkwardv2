<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Incentive\\Providers\\IncentiveServiceProvider',
    1 => 'Modules\\Incentive\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Incentive\\Providers\\IncentiveServiceProvider',
    1 => 'Modules\\Incentive\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);