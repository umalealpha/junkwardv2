<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Inventory\\Providers\\InventoryServiceProvider',
    1 => 'Modules\\Inventory\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Inventory\\Providers\\InventoryServiceProvider',
    1 => 'Modules\\Inventory\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);