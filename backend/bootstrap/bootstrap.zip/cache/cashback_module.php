<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cashback\\Providers\\CashbackServiceProvider',
    1 => 'Modules\\Cashback\\Providers\\EventServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cashback\\Providers\\CashbackServiceProvider',
    1 => 'Modules\\Cashback\\Providers\\EventServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);